<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PartnerIpStat extends Model
{
    protected $table ="partners_ipstats";
    protected $guarded=[];
    public $timestamps = false;
    
}
