<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PartnersTranscation extends Model
{
    protected $table ='partners_transaction';
    public $timestamps = false;
    protected $guarded=[];
}